# EduSmart backend application package
